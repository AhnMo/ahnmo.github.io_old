#include <stdio.h>
#include <iostream>
#include "pin.H"
using namespace std;

void Instruction(INS ins, VOID* v)
{

	printf("all code : %s\n",INS_Disassemble(ins).c_str());
        
}

int main(int argc,char* argv[])
{

        if(PIN_Init(argc,argv))
                return -1;

        INS_AddInstrumentFunction(Instruction,0);
        PIN_StartProgram();
        return 0;
}
