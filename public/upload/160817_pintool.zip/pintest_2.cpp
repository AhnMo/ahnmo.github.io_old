#include <stdio.h>
#include <iostream>
#include "pin.H"
using namespace std;
#define START 0x400504//main함수의 주소값
#define END   0x401000

void Instruction(INS ins, VOID* v)
{
        long int a = (long int)INS_Address(ins);//ins의 주소값
        if(START<=a && a<=END)  //해당 주소값 사이의 값만 출력
        {
        	    if((strncmp(INS_Disassemble(ins).c_str(),"cmp",3)==0))//cmp이면 출력
        	    {
                	printf("cmp code : %s\n",INS_Disassemble(ins).c_str());
        	    }
        }
}

int main(int argc,char* argv[])
{

        if(PIN_Init(argc,argv))
                return -1;

        INS_AddInstrumentFunction(Instruction,0);
        PIN_StartProgram();
        return 0;
}
