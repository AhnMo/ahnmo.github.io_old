#include <stdio.h>
#include <string.h>

int  main()
{
        char input[10];
        scanf("%s",input);

        if(input[0]=='A')
        {

                printf("Good!!");
        }
        return 0;
}
