#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "pin.H"
using namespace std;
#define START 0x0000000000400620//main함수의 주소값
#define END   0x000000000040090d

char key[100];
int i=0;

void Instruction(INS ins, VOID* v)
{
        char buf[100],buf2[100];
        int hex;
        long int a = (long int)INS_Address(ins);//ins의 주소값
        if(START<=a && a<=END)  //해당 주소값 사이의 값만 출력
        {
        	    if((strncmp(INS_Disassemble(ins).c_str(),"cmp",3)==0))//cmp이면 출력
        	    {
                	printf("cmp code : %s\n",INS_Disassemble(ins).c_str());
                        INS_Delete(INS_Next(ins));
                        sprintf(buf,INS_Disassemble(ins).c_str());
                        strncpy(buf2,(buf+10),2);
                        hex = (int)strtol(buf2, NULL, 16);
                        key[i]=(char)hex;
                        i++;
        	    }
                printf("%s",key);

        }
}

int main(int argc,char* argv[])
{

        if(PIN_Init(argc,argv))
                return -1;

        INS_AddInstrumentFunction(Instruction,0);
        PIN_StartProgram();
        printf("%s",key);
        return 0;
}
